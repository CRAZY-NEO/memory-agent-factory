# 冻结算法部署包

本包导出的是已经通过验证集和最终测试的选定算法。运行不需要安装 Agent Factory、连接 Ollama 或 Jetson。
代码、接口、训练样本（分类任务）及指标摘要见 `plugin.json` 和 `report.json`。

## 本地运行

需要 Python 3.11+（推荐 3.12）。在解压目录执行：

```bash
python3 -m venv .venv
.venv/bin/python -m pip install -r requirements.txt
.venv/bin/python run.py
.venv/bin/python run.py --input example_input.json
```

Windows 对应使用 `.venv\Scripts\python.exe`。`--input -` 可从标准输入读取 JSON。
运行器检查代码哈希、输入输出接口及输入未被修改。依赖只列算法直接使用的包，固定到验证环境记录的版本；pip 会安装其传递依赖。
首次安装依赖或构建镜像需要网络。安装后执行算法无需联网。跨操作系统和 CPU 架构仍取决于依赖包提供的 wheel。

输入包含 `query`、`memories`（每条含 `id`、`text`，可含 `source`）、`top_k`；输出为按分数降序排列的 `{id, score}` 列表。包内示例为合成数据，未包含工作区的记忆库。

## Docker 运行

```bash
docker build -t exported-memory-algorithm .
docker run --rm --network none --read-only --cap-drop ALL --security-opt no-new-privileges --memory 512m --cpus 1 --pids-limit 64 --tmpfs /tmp:rw,noexec,nosuid,size=32m exported-memory-algorithm
```

使用自有输入：增加 `-v "$PWD/input.json:/input.json:ro"`，在镜像名后加 `--input /input.json`。
本地 Python 调用不会建立安全沙箱，Docker 示例提供进程资源与网络隔离。容器命令不会自动终止长期运行的任务；按 Ctrl+C 可取消。

## 来源与验证范围

`report.json` 是脱敏后的指标摘要，不包含模型提示词、访问密钥、查询/测试文本或验证标签。
若算法来自外部仓库，`source.json` 与 `licenses/` 保留固定提交、许可证和原始许可文本。
最终测试通过表示在原数据和门槛下通过，不保证任意新数据上的效果。哈希用于检测意外篡改，不是数字签名。
