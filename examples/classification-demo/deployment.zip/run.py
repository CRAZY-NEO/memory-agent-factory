"""Run the frozen algorithm on a JSON input; no factory or LLM required."""
import argparse
import copy
import hashlib
import importlib.util
import json
import math
import sys
from pathlib import Path

ROOT = Path(__file__).resolve().parent


def read_verified(name, expected):
    path = ROOT / name
    if path.is_symlink() or not path.resolve().is_relative_to(ROOT):
        raise ValueError("Unsafe bundle path")
    content = path.read_bytes()
    if hashlib.sha256(content).hexdigest() != expected:
        raise ValueError("Bundle hash mismatch: " + name)
    return content


def invoke(payload, manifest):
    source = read_verified("algorithm.py", manifest["code_hash"])
    spec = importlib.util.spec_from_file_location("frozen_algorithm", ROOT / "algorithm.py")
    module = importlib.util.module_from_spec(spec)
    # Execute the exact verified bytes, avoiding a second file read during load.
    exec(compile(source, str(ROOT / "algorithm.py"), "exec"), module.__dict__)
    if manifest["task"] == "memory_classification":
        texts = payload.get("texts")
        if not isinstance(texts, list) or any(not isinstance(text, str) for text in texts):
            raise ValueError("texts must be a list of strings")
        training = json.loads(read_verified("training_examples.json", manifest["training_data_hash"]))
        before = copy.deepcopy((texts, training))
        result = module.classify(texts, training)
        if (texts, training) != before:
            raise ValueError("Algorithm mutated classification inputs")
        labels = {row["label"] for row in training}
        if (not isinstance(result, list) or len(result) != len(texts)
                or any(not isinstance(label, str) or label not in labels for label in result)):
            raise ValueError("Classification output violates the label contract")
        return result
    query, memories, top_k = payload.get("query"), payload.get("memories"), payload.get("top_k", 5)
    if not isinstance(query, str) or type(top_k) is not int or not isinstance(memories, list):
        raise ValueError("Expected query: string, memories: list, top_k: integer")
    if any(not isinstance(row, dict) or not isinstance(row.get("id"), str)
           or not row["id"] or not isinstance(row.get("text"), str) or not row["text"] for row in memories):
        raise ValueError("Each memory needs nonempty string id and text")
    ids = {row["id"] for row in memories}
    if len(ids) != len(memories):
        raise ValueError("Memory IDs must be unique")
    before = copy.deepcopy(memories)
    result = module.retrieve(query, memories, top_k)
    if memories != before:
        raise ValueError("Algorithm mutated memories")
    if not isinstance(result, list) or len(result) > max(top_k, 0):
        raise ValueError("Invalid retrieval result count")
    if any(not isinstance(hit, dict) or set(hit) != {"id", "score"}
           or not isinstance(hit["id"], str) or hit["id"] not in ids
           or type(hit["score"]) not in {int, float} or not math.isfinite(hit["score"])
           or hit["score"] < 0 for hit in result):
        raise ValueError("Invalid retrieval output fields")
    if len({hit["id"] for hit in result}) != len(result):
        raise ValueError("Duplicate retrieval result IDs")
    if result != sorted(result, key=lambda hit: (-hit["score"], hit["id"])):
        raise ValueError("Results must be sorted by descending score, then ID")
    if (not query.strip() or not memories or top_k <= 0) and result:
        raise ValueError("Empty input must return []")
    return result


def main():
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--input", default=str(ROOT / "example_input.json"), help="JSON path, or - for stdin")
    args = parser.parse_args()
    manifest = json.loads((ROOT / "plugin.json").read_text(encoding="utf-8"))
    if manifest.get("task") not in {"memory_retrieval", "memory_classification"} or manifest.get("interface_version") != "1":
        raise ValueError("Unsupported bundle interface")
    payload = json.load(sys.stdin) if args.input == "-" else json.loads(Path(args.input).read_text(encoding="utf-8"))
    if not isinstance(payload, dict):
        raise ValueError("Input must be a JSON object")
    print(json.dumps(invoke(payload, manifest), ensure_ascii=False, allow_nan=False))


if __name__ == "__main__":
    try:
        main()
    except Exception as error:
        print(type(error).__name__ + ": " + str(error), file=sys.stderr)
        sys.exit(1)
